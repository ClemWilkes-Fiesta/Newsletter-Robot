print('stub send script - use the detailed version from earlier message')
