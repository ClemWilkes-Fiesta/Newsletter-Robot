open('output/newsletter.html','w').write('<h1>Test Newsletter</h1>')
print('Wrote output/newsletter.html')
