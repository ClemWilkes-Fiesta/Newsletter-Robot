print('stub ingest script - use the detailed version from earlier message')
