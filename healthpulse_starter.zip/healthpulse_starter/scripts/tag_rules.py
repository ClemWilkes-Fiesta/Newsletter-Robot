print('stub tag script - use the detailed version from earlier message')
