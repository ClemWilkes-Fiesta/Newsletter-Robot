INSERT INTO themes(theme_id,name,description) VALUES ('cardiovascular','Cardiovascular Services','Cardio...'),('imaging','Imaging & Radiology','...');
