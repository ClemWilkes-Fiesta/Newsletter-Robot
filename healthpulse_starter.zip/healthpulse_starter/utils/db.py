import os
from sqlalchemy import create_engine
from dotenv import load_dotenv
load_dotenv()

def engine():
    url = os.environ.get('POSTGRES_URL')
    if not url:
        host=os.environ['POSTGRES_HOST']; port=os.environ.get('POSTGRES_PORT','5432'); db=os.environ['POSTGRES_DB']; user=os.environ['POSTGRES_USER']; pw=os.environ['POSTGRES_PASSWORD']; ssl=os.environ.get('POSTGRES_SSLMODE','require')
        url=f'postgresql+psycopg2://{user}:{pw}@{host}:{port}/{db}?sslmode={ssl}'
    return create_engine(url, pool_pre_ping=True)
