import hashlib, urllib.parse, requests
from trafilatura import extract

def canonical_id(url:str)->str:
    return hashlib.sha256(url.encode()).hexdigest()[:16]

def get_domain(url:str)->str:
    return urllib.parse.urlparse(url).netloc.lower()

def fetch_text(url:str,timeout:int=20)->str:
    r=requests.get(url,timeout=timeout,headers={'User-Agent':'Mozilla/5.0'}); r.raise_for_status(); txt=extract(r.text,url=url) or ''; return txt.strip()
